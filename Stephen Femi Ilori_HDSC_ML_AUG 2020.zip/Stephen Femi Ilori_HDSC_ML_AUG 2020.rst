.. code:: ipython3

    import numpy as np
    import pandas as pd
    import seaborn as sns
    from statsmodels.graphics.tsaplots 
    import plot_acf
    import matplotlib.pyplot as plt
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.feature_selection import RFE
    from sklearn.ensemble import ExtraTreesRegressor
    import matplotlib.pyplot as plt
    from pandas.tools.plotting import scatter_matrix
    from sklearn import cross_validation
    from sklearn.linear_model import LinearRegression
    from sklearn.linear_model import Ridge
    from sklearn.linear_model import Lasso
    from sklearn.linear_model import ElasticNet
    from sklearn.ensemble import BaggingRegressor
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.svm import SVR
    from keras.models import Sequential
    from keras.layers import Dense
    from keras.layers import Dropout
    from keras.utils import np_utils
    from sklearn.model_selection import StratifiedKFold
    from keras.constraints import maxnorm
    #from sklearn.metrics import explained_variance_score
    #from sklearn.metrics import mean_squared_error
    from sklearn.metrics import mean_absolute_error


::


      File "<ipython-input-31-a870bb9db346>", line 4
        from statsmodels.graphics.tsaplots
                                           ^
    SyntaxError: invalid syntax
    


.. code:: ipython3

    ML_data = url =  "https://archive.ics.uci.edu/ml/machine-learning-databases/00374/energydata_complete.csv"
    df = pd.read_csv("https://archive.ics.uci.edu/ml/machine-learning-databases/00374/energydata_complete.csv", )
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>date</th>
          <th>Appliances</th>
          <th>lights</th>
          <th>T1</th>
          <th>RH_1</th>
          <th>T2</th>
          <th>RH_2</th>
          <th>T3</th>
          <th>RH_3</th>
          <th>T4</th>
          <th>...</th>
          <th>T9</th>
          <th>RH_9</th>
          <th>T_out</th>
          <th>Press_mm_hg</th>
          <th>RH_out</th>
          <th>Windspeed</th>
          <th>Visibility</th>
          <th>Tdewpoint</th>
          <th>rv1</th>
          <th>rv2</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>0</td>
          <td>2016-01-11 17:00:00</td>
          <td>60</td>
          <td>30</td>
          <td>19.89</td>
          <td>47.596667</td>
          <td>19.2</td>
          <td>44.790000</td>
          <td>19.79</td>
          <td>44.730000</td>
          <td>19.000000</td>
          <td>...</td>
          <td>17.033333</td>
          <td>45.53</td>
          <td>6.600000</td>
          <td>733.5</td>
          <td>92.0</td>
          <td>7.000000</td>
          <td>63.000000</td>
          <td>5.3</td>
          <td>13.275433</td>
          <td>13.275433</td>
        </tr>
        <tr>
          <td>1</td>
          <td>2016-01-11 17:10:00</td>
          <td>60</td>
          <td>30</td>
          <td>19.89</td>
          <td>46.693333</td>
          <td>19.2</td>
          <td>44.722500</td>
          <td>19.79</td>
          <td>44.790000</td>
          <td>19.000000</td>
          <td>...</td>
          <td>17.066667</td>
          <td>45.56</td>
          <td>6.483333</td>
          <td>733.6</td>
          <td>92.0</td>
          <td>6.666667</td>
          <td>59.166667</td>
          <td>5.2</td>
          <td>18.606195</td>
          <td>18.606195</td>
        </tr>
        <tr>
          <td>2</td>
          <td>2016-01-11 17:20:00</td>
          <td>50</td>
          <td>30</td>
          <td>19.89</td>
          <td>46.300000</td>
          <td>19.2</td>
          <td>44.626667</td>
          <td>19.79</td>
          <td>44.933333</td>
          <td>18.926667</td>
          <td>...</td>
          <td>17.000000</td>
          <td>45.50</td>
          <td>6.366667</td>
          <td>733.7</td>
          <td>92.0</td>
          <td>6.333333</td>
          <td>55.333333</td>
          <td>5.1</td>
          <td>28.642668</td>
          <td>28.642668</td>
        </tr>
        <tr>
          <td>3</td>
          <td>2016-01-11 17:30:00</td>
          <td>50</td>
          <td>40</td>
          <td>19.89</td>
          <td>46.066667</td>
          <td>19.2</td>
          <td>44.590000</td>
          <td>19.79</td>
          <td>45.000000</td>
          <td>18.890000</td>
          <td>...</td>
          <td>17.000000</td>
          <td>45.40</td>
          <td>6.250000</td>
          <td>733.8</td>
          <td>92.0</td>
          <td>6.000000</td>
          <td>51.500000</td>
          <td>5.0</td>
          <td>45.410389</td>
          <td>45.410389</td>
        </tr>
        <tr>
          <td>4</td>
          <td>2016-01-11 17:40:00</td>
          <td>60</td>
          <td>40</td>
          <td>19.89</td>
          <td>46.333333</td>
          <td>19.2</td>
          <td>44.530000</td>
          <td>19.79</td>
          <td>45.000000</td>
          <td>18.890000</td>
          <td>...</td>
          <td>17.000000</td>
          <td>45.40</td>
          <td>6.133333</td>
          <td>733.9</td>
          <td>92.0</td>
          <td>5.666667</td>
          <td>47.666667</td>
          <td>4.9</td>
          <td>10.084097</td>
          <td>10.084097</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 29 columns</p>
    </div>



.. code:: ipython3

    # dataset info
    
    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 19735 entries, 0 to 19734
    Data columns (total 29 columns):
    date           19735 non-null object
    Appliances     19735 non-null int64
    lights         19735 non-null int64
    T1             19735 non-null float64
    RH_1           19735 non-null float64
    T2             19735 non-null float64
    RH_2           19735 non-null float64
    T3             19735 non-null float64
    RH_3           19735 non-null float64
    T4             19735 non-null float64
    RH_4           19735 non-null float64
    T5             19735 non-null float64
    RH_5           19735 non-null float64
    T6             19735 non-null float64
    RH_6           19735 non-null float64
    T7             19735 non-null float64
    RH_7           19735 non-null float64
    T8             19735 non-null float64
    RH_8           19735 non-null float64
    T9             19735 non-null float64
    RH_9           19735 non-null float64
    T_out          19735 non-null float64
    Press_mm_hg    19735 non-null float64
    RH_out         19735 non-null float64
    Windspeed      19735 non-null float64
    Visibility     19735 non-null float64
    Tdewpoint      19735 non-null float64
    rv1            19735 non-null float64
    rv2            19735 non-null float64
    dtypes: float64(26), int64(2), object(1)
    memory usage: 4.4+ MB
    

.. code:: ipython3

    # checking if there are missing values in the datset
    
    df.isnull().sum()




.. parsed-literal::

    date           0
    Appliances     0
    lights         0
    T1             0
    RH_1           0
    T2             0
    RH_2           0
    T3             0
    RH_3           0
    T4             0
    RH_4           0
    T5             0
    RH_5           0
    T6             0
    RH_6           0
    T7             0
    RH_7           0
    T8             0
    RH_8           0
    T9             0
    RH_9           0
    T_out          0
    Press_mm_hg    0
    RH_out         0
    Windspeed      0
    Visibility     0
    Tdewpoint      0
    rv1            0
    rv2            0
    dtype: int64



.. code:: ipython3

    # descriptive summary of the data
    
    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Appliances</th>
          <th>lights</th>
          <th>T1</th>
          <th>RH_1</th>
          <th>T2</th>
          <th>RH_2</th>
          <th>T3</th>
          <th>RH_3</th>
          <th>T4</th>
          <th>RH_4</th>
          <th>...</th>
          <th>T9</th>
          <th>RH_9</th>
          <th>T_out</th>
          <th>Press_mm_hg</th>
          <th>RH_out</th>
          <th>Windspeed</th>
          <th>Visibility</th>
          <th>Tdewpoint</th>
          <th>rv1</th>
          <th>rv2</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>count</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>...</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
          <td>19735.000000</td>
        </tr>
        <tr>
          <td>mean</td>
          <td>97.694958</td>
          <td>3.801875</td>
          <td>21.686571</td>
          <td>40.259739</td>
          <td>20.341219</td>
          <td>40.420420</td>
          <td>22.267611</td>
          <td>39.242500</td>
          <td>20.855335</td>
          <td>39.026904</td>
          <td>...</td>
          <td>19.485828</td>
          <td>41.552401</td>
          <td>7.411665</td>
          <td>755.522602</td>
          <td>79.750418</td>
          <td>4.039752</td>
          <td>38.330834</td>
          <td>3.760707</td>
          <td>24.988033</td>
          <td>24.988033</td>
        </tr>
        <tr>
          <td>std</td>
          <td>102.524891</td>
          <td>7.935988</td>
          <td>1.606066</td>
          <td>3.979299</td>
          <td>2.192974</td>
          <td>4.069813</td>
          <td>2.006111</td>
          <td>3.254576</td>
          <td>2.042884</td>
          <td>4.341321</td>
          <td>...</td>
          <td>2.014712</td>
          <td>4.151497</td>
          <td>5.317409</td>
          <td>7.399441</td>
          <td>14.901088</td>
          <td>2.451221</td>
          <td>11.794719</td>
          <td>4.194648</td>
          <td>14.496634</td>
          <td>14.496634</td>
        </tr>
        <tr>
          <td>min</td>
          <td>10.000000</td>
          <td>0.000000</td>
          <td>16.790000</td>
          <td>27.023333</td>
          <td>16.100000</td>
          <td>20.463333</td>
          <td>17.200000</td>
          <td>28.766667</td>
          <td>15.100000</td>
          <td>27.660000</td>
          <td>...</td>
          <td>14.890000</td>
          <td>29.166667</td>
          <td>-5.000000</td>
          <td>729.300000</td>
          <td>24.000000</td>
          <td>0.000000</td>
          <td>1.000000</td>
          <td>-6.600000</td>
          <td>0.005322</td>
          <td>0.005322</td>
        </tr>
        <tr>
          <td>25%</td>
          <td>50.000000</td>
          <td>0.000000</td>
          <td>20.760000</td>
          <td>37.333333</td>
          <td>18.790000</td>
          <td>37.900000</td>
          <td>20.790000</td>
          <td>36.900000</td>
          <td>19.530000</td>
          <td>35.530000</td>
          <td>...</td>
          <td>18.000000</td>
          <td>38.500000</td>
          <td>3.666667</td>
          <td>750.933333</td>
          <td>70.333333</td>
          <td>2.000000</td>
          <td>29.000000</td>
          <td>0.900000</td>
          <td>12.497889</td>
          <td>12.497889</td>
        </tr>
        <tr>
          <td>50%</td>
          <td>60.000000</td>
          <td>0.000000</td>
          <td>21.600000</td>
          <td>39.656667</td>
          <td>20.000000</td>
          <td>40.500000</td>
          <td>22.100000</td>
          <td>38.530000</td>
          <td>20.666667</td>
          <td>38.400000</td>
          <td>...</td>
          <td>19.390000</td>
          <td>40.900000</td>
          <td>6.916667</td>
          <td>756.100000</td>
          <td>83.666667</td>
          <td>3.666667</td>
          <td>40.000000</td>
          <td>3.433333</td>
          <td>24.897653</td>
          <td>24.897653</td>
        </tr>
        <tr>
          <td>75%</td>
          <td>100.000000</td>
          <td>0.000000</td>
          <td>22.600000</td>
          <td>43.066667</td>
          <td>21.500000</td>
          <td>43.260000</td>
          <td>23.290000</td>
          <td>41.760000</td>
          <td>22.100000</td>
          <td>42.156667</td>
          <td>...</td>
          <td>20.600000</td>
          <td>44.338095</td>
          <td>10.408333</td>
          <td>760.933333</td>
          <td>91.666667</td>
          <td>5.500000</td>
          <td>40.000000</td>
          <td>6.566667</td>
          <td>37.583769</td>
          <td>37.583769</td>
        </tr>
        <tr>
          <td>max</td>
          <td>1080.000000</td>
          <td>70.000000</td>
          <td>26.260000</td>
          <td>63.360000</td>
          <td>29.856667</td>
          <td>56.026667</td>
          <td>29.236000</td>
          <td>50.163333</td>
          <td>26.200000</td>
          <td>51.090000</td>
          <td>...</td>
          <td>24.500000</td>
          <td>53.326667</td>
          <td>26.100000</td>
          <td>772.300000</td>
          <td>100.000000</td>
          <td>14.000000</td>
          <td>66.000000</td>
          <td>15.500000</td>
          <td>49.996530</td>
          <td>49.996530</td>
        </tr>
      </tbody>
    </table>
    <p>8 rows × 28 columns</p>
    </div>



.. code:: ipython3

    print(f'The number of rows is the dataset is {df.shape[0]} \nThe number of columns in the dataset is {df.shape[1]}')


.. parsed-literal::

    The number of rows is the dataset is 19735 
    The number of columns in the dataset is 29
    

.. code:: ipython3

    # lets visualize the histogram of all the features to understand the  distribution
    
    df.hist(bins=20, figsize=(20,20));



.. image:: output_6_0.png


.. code:: ipython3

    # dropping the lights column
    df.drop(['lights'], axis=1,inplace=True)
    
    # dropping the date column since its not a time series problem
    df.drop(['date'], axis=1, inplace=True)

.. code:: ipython3

    # focussed displots for RH_6 , RH_out , Visibility , Windspeed due to irregular distribution
    
    fig, ax = plt.subplots(2,2,figsize=(12,8))
    ax1 = sns.distplot(df["RH_6"],  bins=10, ax= ax[0][0])
    ax2 = sns.distplot(df["RH_out"],bins=10, ax=ax[0][1])
    ax3 = sns.distplot(df["Visibility"],bins=10, ax=ax[1][0])
    ax4 = sns.distplot(df["Windspeed"],bins=10, ax=ax[1][1])



.. image:: output_8_0.png


.. code:: ipython3

    # lets take a closer look at the appliance column
    
    df['Appliances'].hist(bins = 100, figsize=(10,5))
    plt.xlabel('Appliance energy consumption in wh', fontsize='x-large')
    plt.ylabel('Frequency', fontsize='x-large');
    



.. image:: output_9_0.png


.. code:: ipython3

    # calculating the percentage of appliance enegry consumption less than 200 wh
    
    print(f" Percentage of the appliance energy consumption less than 200 Wh is: {round((df[df['Appliances'] <= 200]['Appliances'].count()) / len(df['Appliances']) * 100, 2)}%")


.. parsed-literal::

     Percentage of the appliance energy consumption less than 200 Wh is: 90.29%
    

.. code:: ipython3

    # Use the weather , temperature , applainces and random column to see the correlation
    
    corr = df.corr()
    
    # Mask the repeated values
    mask = np.zeros_like(corr, dtype=np.bool)
    mask[np.triu_indices_from(mask)] = True
      
    fig = plt.figure(figsize=(17, 15))
    #Generate Heat Map, allow annotations and place floats in map
    sns.heatmap(corr, annot=True, fmt=".2f" , mask=mask);



.. image:: output_11_0.png


.. code:: ipython3

    # lets see how each features correlates with the target column
    cor_matrix = df.corr()
    cor_matrix['Appliances']




.. parsed-literal::

    Appliances     1.000000
    lights         0.197278
    T1             0.055447
    RH_1           0.086031
    T2             0.120073
    RH_2          -0.060465
    T3             0.085060
    RH_3           0.036292
    T4             0.040281
    RH_4           0.016965
    T5             0.019760
    RH_5           0.006955
    T6             0.117638
    RH_6          -0.083178
    T7             0.025801
    RH_7          -0.055642
    T8             0.039572
    RH_8          -0.094039
    T9             0.010010
    RH_9          -0.051462
    T_out          0.099155
    Press_mm_hg   -0.034885
    RH_out        -0.152282
    Windspeed      0.087122
    Visibility     0.000230
    Tdewpoint      0.015353
    rv1           -0.011145
    rv2           -0.011145
    Name: Appliances, dtype: float64



.. code:: ipython3

    import pandas as pd
    import numpy as np
    from sklearn import datasets, linear_model
    from sklearn.model_selection import train_test_split
    from matplotlib import pyplot as plt
    from sklearn.cross_validation  import train_test_split

.. code:: ipython3

    from sklearn.model_selection import train_test_split
    
    y = df.pop('output')
    
    X = df
    
    X_train,X_test,y_train,y_test = train_test_split(X.index,y,test_size=0.2)
    X.iloc[X_train] # return dataframe train


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-42-67ef4af175e6> in <module>
          1 from sklearn.model_selection import train_test_split
          2 
    ----> 3 y = df.pop('output')
          4 
          5 X = df
    

    NameError: name 'df' is not defined


.. code:: ipython3

    # splitting data into training and testing set
    
    from sklearn.model_selection import train_test_split
    
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size = 0.3, random_state = 42)


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-36-eb2338ac5cc2> in <module>
          3 from sklearn.model_selection import train_test_split
          4 
    ----> 5 X_train, X_test, y_train, y_test = train_test_split(features, target, test_size = 0.3, random_state = 42)
    

    NameError: name 'features' is not defined


.. code:: ipython3

    print(f'shape of train set is {X_train.shape}')
    print(f'shape of test set is {X_test.shape}')


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-28-cedd866723ce> in <module>
    ----> 1 print(f'shape of train set is {X_train.shape}')
          2 print(f'shape of test set is {X_test.shape}')
    

    NameError: name 'X_train' is not defined


.. code:: ipython3

    # importing the required algorithms
    from sklearn.linear_model import Ridge, Lasso, LinearRegression, ElasticNet
    from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, GradientBoostingRegressor
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.neighbors import KNeighborsRegressor
    
    
    # import the evaluation metrics
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    
    # create a dictionary of different algorithms 
    models = {'Ridge': Ridge(),
            'Lasso': Lasso(),
            'ElasticNet':ElasticNet(),
            'LinearRegression':LinearRegression(),
            'KNeighborsRegressor':KNeighborsRegressor(),
            'RandomForestRegressor':RandomForestRegressor(),
            'ExtraTreesRegressor':ExtraTreesRegressor(),
            'GradientBoostingRegressor':GradientBoostingRegressor(),
            'DecisionTreeRegressor':DecisionTreeRegressor()}

.. code:: ipython3

    # helper funtion to compute the score, RMSE, time on the training and testing set
    
    def pipeline(models, X_train, X_test, y_train, y_test)


::


      File "<ipython-input-11-253e1317175e>", line 3
        def pipeline(models, X_train, X_test, y_train, y_test)
                                                              ^
    SyntaxError: invalid syntax
    


.. code:: ipython3

    from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
    
    # define the param grid
    def param_grid = [{
                  'max_depth': [80, 150, 200,250],
                  'n_estimators' : [10, 50, 100, 200, 250],
                  'max_features': ["auto", "sqrt", "log2"]
                }]
    
    reg = ExtraTreesRegressor(random_state=42)
    
    # Instantiate the grid search model
    grid_search = RandomizedSearchCV(reg, param_grid, cv = 6, n_jobs = -1 , scoring='r2' , verbose=2)
    
    # fit the gridserch model
    grid_search.fit(X_train, y_train)


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-30-7fd6e596a66b> in <module>
          8             }]
          9 
    ---> 10 reg = ExtraTreesRegressor(random_state=42)
         11 
         12 # Instantiate the grid search model
    

    NameError: name 'ExtraTreesRegressor' is not defined


.. code:: ipython3

    # check for the best param fot the ExtraTreeReggressor
    
    print(f'best param of the ExtraTreeRegressor is: {grid_search.best_params_}')


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-38-805dc58dc556> in <module>
          1 # check for the best param fot the ExtraTreeReggressor
          2 
    ----> 3 print(f'best param of the ExtraTreeRegressor is: {grid_search.best_params_}')
    

    NameError: name 'grid_search' is not defined


.. code:: ipython3

    # Best possible estimator for ExtraTreesRegressor
    
    best_model = grid_search.best_estimator_
    
    print(f'print R2_score on training_set with tuned parameters: {best_model.score(X_train, y_train)}')
    print(f'print R2_score on testing_set with tuned parameters: {round(best_model.score(X_test, y_test), 3)}')
    print(f'print MSE_score on testing_set with tuned parameters: {round(mean_squared_error(y_test, best_model.predict(X_test)), 3)}')
    print(f'print RMSE_score on testing_set with tuned parameters: {round(np.sqrt(mean_squared_error(y_test, best_model.predict(X_test))), 3)}')


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-39-40dc40703428> in <module>
          1 # Best possible estimator for ExtraTreesRegressor
          2 
    ----> 3 best_model = grid_search.best_estimator_
          4 
          5 print(f'print R2_score on training_set with tuned parameters: {best_model.score(X_train, y_train)}')
    

    NameError: name 'grid_search' is not defined


.. code:: ipython3

    # intantiate the grid params
    param_grid = [
     {'n_estimators': [3, 10, 30, 50], 'max_features': [2, 4, 6, 8, 10],
      'max_depth':[10, 15]},
     {'bootstrap': [False], 'n_estimators': [1, 3, 10], 'max_features': [2, 3, 4]},
     ]
    
    # instantiate the random forest regressor
    forest_reg = RandomForestRegressor()
    
    # instanntiate the grid serch
    grid_search = GridSearchCV(forest_reg, param_grid, cv=6, scoring='r2')
    
    # fit the grid serchon training data
    grid_search.fit(X_train, y_train)


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-40-1b8c75e06c9d> in <module>
          7 
          8 # instantiate the random forest regressor
    ----> 9 forest_reg = RandomForestRegressor()
         10 
         11 # instanntiate the grid serch
    

    NameError: name 'RandomForestRegressor' is not defined


.. code:: ipython3

    # get best params
    grid_search.best_params_


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-41-fa01e7d1391c> in <module>
          1 # get best params
    ----> 2 grid_search.best_params_
    

    NameError: name 'grid_search' is not defined


.. code:: ipython3

    # get best model
    model = grid_search.best_estimator_


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-42-9d29955148f2> in <module>
          1 # get best model
    ----> 2 model = grid_search.best_estimator_
    

    NameError: name 'grid_search' is not defined


.. code:: ipython3

    # Get sorted list of features in order of importance
    feature_indices = np.argsort(grid_search.best_estimator_.feature_importances_)


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-43-863feee40afd> in <module>
          1 # Get sorted list of features in order of importance
    ----> 2 feature_indices = np.argsort(grid_search.best_estimator_.feature_importances_)
    

    NameError: name 'grid_search' is not defined


.. code:: ipython3

    # Get top 10 most important feature 
    names[0:10]


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-44-44dbd82a55dc> in <module>
          1 # Get top 10 most important feature
    ----> 2 names[0:10]
    

    NameError: name 'names' is not defined


.. code:: ipython3

    df = df.drop(['lights'], axis=1, inplace=True)
    
    # dropping the date column as instructed
    
    df = df.drop(['date'], axis=1, inplace=True)


::


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-31-80356959405a> in <module>
    ----> 1 df = df.drop(['lights'], axis=1, inplace=True)
          2 
          3 # dropping the date column as instructed
          4 
          5 df = df.drop(['date'], axis=1, inplace=True)
    

    NameError: name 'df' is not defined




